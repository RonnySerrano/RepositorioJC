using System.ComponentModel.DataAnnotations;

namespace JCalentadores.Models
{
    public class Tecnico:Personas
    { 
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "El nivel de estudio es obligatorio")]
        public string NivelEstudio { get ;  set; }
        [Required(ErrorMessage = "El numero de registro es obligatorio")]
        public int NumeroRegistro { get ;  set; }



    }
}