using System.ComponentModel.DataAnnotations;

namespace JCalentadores.Models
{
    public class Administradores:Personas
    { 
        [Key]
        public int Id { get; set; }
        
    }
}