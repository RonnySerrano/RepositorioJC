using System.ComponentModel.DataAnnotations;

namespace JCalentadores.Models
{
    public class Cliente:Personas
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "El rut es obligatorio")]
        public string Rut { get ;  set; }
        [Required(ErrorMessage = "La forma de pago es obligatorio")]
        public string FormaPago { get ;  set; }

    }
}