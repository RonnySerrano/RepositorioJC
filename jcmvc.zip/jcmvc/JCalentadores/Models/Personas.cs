using System.ComponentModel.DataAnnotations;

namespace JCalentadores.Models
{
    public class Personas
    {
        [Key]
        public int Id { get; set; }


        [Required(ErrorMessage = "El usuario es obligatorio")]
        public string UserName { get ;  set; }
        [Required(ErrorMessage = "La contraseña es obligatorio")]
        public string Contraseña { get ;  set; }
        [Required(ErrorMessage = "El tipo de identificacion es obligatorio")]
        public string TipIdentificacion { get ;  set; }
        [Required(ErrorMessage = "El numero de identificacion es obligatorio")]
        public string NumIdentificacion { get ;  set; }
        [Required(ErrorMessage = "El nombre es obligatorio")]
        public string Nombre { get ;  set; }
        [Required(ErrorMessage = "El apellido es obligatorio")]
        public string Apellido { get ;  set; }
        [Required(ErrorMessage = "La fecha es obligatorio")]
        public string FechaNacimiento { get ;  set; }
        [Required(ErrorMessage = "El telefono es obligatorio")]
        public string Telefono { get ;  set; }
        [Required(ErrorMessage = "El celular es obligatorio")]
        public string Celular { get ;  set; }
        [Required(ErrorMessage = "El email es obligatorio")]
        public string Email { get ;  set; }
        [Required(ErrorMessage = "La direccion es obligatoria")]
        public string DireccionC { get ;  set; }

    }
}