

using Microsoft.EntityFrameworkCore;
using JCalentadores.Models;

namespace JCalentadores.Data
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options)
        {
            // Vacio    
        }

        public DbSet<Personas>? Persona { get; set; }     
        public DbSet<Cliente>? Clientes { get; set; }  
        public DbSet<Tecnico>? Tecnicos { get; set; }  
        public DbSet<Administradores>? Administradors { get; set; }  
    }
}